package com.codelaxy.captchaapp;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.Settings;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.codelaxy.captchaapp.Api.RetrofitClient;
import com.codelaxy.captchaapp.Models.Captcha;
import com.codelaxy.captchaapp.Models.CaptchaResponse;
import com.codelaxy.captchaapp.Models.DefaultResponse;
import com.codelaxy.captchaapp.Models.RateResponse;
import com.codelaxy.captchaapp.Models.UserCountResponse;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Collections;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CaptchaActivity extends AppCompatActivity implements View.OnClickListener {

    @BindView(R.id.toolbar)
    android.support.v7.widget.Toolbar toolbar;
    @BindView(R.id.captcha_image)
    ImageView captcha_image;
    @BindView(R.id.captcha_text)
    EditText captcha_text;
    @BindView(R.id.btn_continue)
    Button btn_continue;
    @BindView(R.id.btn_skip)
    Button btn_skip;
    @BindView(R.id.right_wrong)
    TextView right_wrong;
    @BindView(R.id.captcha_type)
    TextView captcha_type;
    @BindView(R.id.timer_text)
    TextView timer_text;
    @BindView(R.id.next_order)
    Button next_order;
    @BindView(R.id.balance)
    TextView balance;

    int position = 0, right_count, wrong_count;
    String captcha_count, captcha_rate;
    ArrayList<Captcha> dataList;
    String image_url = "http://captchabro.website/CaptchaApi/includes/uploads/";
    CountDownTimer timer;
    boolean timer_running = false;
    String imei;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_captcha);
        ButterKnife.bind(this);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(R.string.toolbar_title);

        next_order.setEnabled(false);

        getUserCount();
        btn_continue.setOnClickListener(this);
        btn_skip.setOnClickListener(this);
        next_order.setOnClickListener(this);
    }

    private void getUserCount() {

        final ProgressDialog dialog = new ProgressDialog(CaptchaActivity.this);
        dialog.setMessage("Please Wait...");
        dialog.setCancelable(false);
        dialog.show();

        Call<UserCountResponse> call = RetrofitClient.getInstance().getApi().getUserCount(Login.str_user_id);
        call.enqueue(new Callback<UserCountResponse>() {
            @Override
            public void onResponse(Call<UserCountResponse> call, Response<UserCountResponse> response) {

                dialog.cancel();
                if (response.code() == 200) {

                    Dexter.withActivity(CaptchaActivity.this)
                            .withPermission(Manifest.permission.READ_PHONE_STATE)
                            .withListener(new PermissionListener() {
                                @Override
                                public void onPermissionGranted(PermissionGrantedResponse response) {

                                    TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
                                    imei = telephonyManager.getDeviceId();
                                }

                                @Override
                                public void onPermissionDenied(PermissionDeniedResponse response) {

                                }

                                @Override
                                public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {

                                }
                            })
                            .check();

                    //String android_id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                    //Log.d("niraj", android_id);

                    if(response.body().getCounts().getUnique_id().equals("not_init"))
                    {
                        Call<DefaultResponse> call1 = RetrofitClient.getInstance().getApi().updateUniqueId(Login.str_user_id, imei);
                        final ProgressDialog progressDialog = new ProgressDialog(CaptchaActivity.this);
                        progressDialog.setCancelable(false);
                        progressDialog.setMessage("Please Wait...");
                        progressDialog.show();

                        call1.enqueue(new Callback<DefaultResponse>() {
                            @Override
                            public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {

                                progressDialog.cancel();

                                if(response.code() == 201){
                                AlertDialog.Builder builder = new AlertDialog.Builder(CaptchaActivity.this);
                                builder.setCancelable(false);
                                builder.setMessage("You user id is successfully initialed. Please Login again to continue");
                                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                        finish();
                                        startActivity(new Intent(CaptchaActivity.this, Login.class));
                                    }
                                }).create().show();
                            }}

                            @Override
                            public void onFailure(Call<DefaultResponse> call, Throwable t) {

                                progressDialog.cancel();
                            }
                        });
                    }

                    else if(response.body().getCounts().getUnique_id().equals(imei))
                    {
                    right_count = Integer.parseInt(response.body().getCounts().getRight_count());
                    wrong_count = Integer.parseInt(response.body().getCounts().getWrong_count());
                    right_wrong.setText(right_count + " / " + wrong_count);

                    captcha_count = response.body().getCounts().getCaptcha_count();
                    captcha_rate = response.body().getCounts().getCaptcha_rate();
                    balance.setText(captcha_count + " / " + captcha_rate + " $");

                    if (right_count >= Integer.parseInt(captcha_count)) {

                        completeOrder();
                    } else
                        getCaptchaData();
                }
                else {
                        AlertDialog.Builder builder = new AlertDialog.Builder(CaptchaActivity.this);
                        builder.setCancelable(false);
                        builder.setMessage("You can use this user id in one phone only. Please Login with another user id");
                        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                finish();
                                startActivity(new Intent(CaptchaActivity.this, Login.class));
                            }
                        }).create().show();
                    }
                }
            }

            @Override
            public void onFailure(Call<UserCountResponse> call, Throwable t) {

                dialog.cancel();
            }
        });
    }

    private void completeOrder() {

        AlertDialog.Builder builder = new AlertDialog.Builder(CaptchaActivity.this);
        builder.setCancelable(false);
        builder.setMessage("Your 1$ payment completed. You can now take payment from company and Click on Next order button to take next order");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialog, int which) {

                dialog.cancel();
                next_order.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                next_order.setEnabled(true);
                btn_continue.setEnabled(false);
                btn_skip.setEnabled(false);
                captcha_text.setEnabled(false);
                btn_continue.setBackgroundColor(getResources().getColor(R.color.light_grey));
                btn_skip.setBackgroundColor(getResources().getColor(R.color.light_grey));
            }
        }).create().show();
    }

    private void getCaptchaData() {

        final ProgressDialog dialog = new ProgressDialog(CaptchaActivity.this);
        dialog.setMessage("Please Wait...");
        dialog.setCancelable(false);
        dialog.show();

        Call<CaptchaResponse> call = RetrofitClient.getInstance().getApi().getCaptcha();
        call.enqueue(new Callback<CaptchaResponse>() {
            @Override
            public void onResponse(Call<CaptchaResponse> call, Response<CaptchaResponse> response) {

                dialog.cancel();
                setDataInFields(response.body().getCaptchas());
            }

            @Override
            public void onFailure(Call<CaptchaResponse> call, Throwable t) {

                dialog.cancel();
            }
        });
    }

    private void setDataInFields(ArrayList<Captcha> captchas) {

        dataList = captchas;
        Picasso.get().load(image_url + captchas.get(position).getImage()).resize(500, 200).into(captcha_image, new com.squareup.picasso.Callback() {
            @Override
            public void onSuccess() {

                if (timer_running) {

                    timer.cancel();
                    startTimer();
                } else
                    startTimer();
            }

            @Override
            public void onError(Exception e) {

            }
        });
        captcha_type.setText("* " + captchas.get(position).getCaptcha_type());
    }

    private void startTimer() {

        timer_running = true;
        int int_timer = Integer.parseInt(Login.str_time);

        timer = new CountDownTimer((int_timer + 1) * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

                timer_text.setText(String.valueOf((millisUntilFinished / 1000)) + " s");
            }

            @Override
            public void onFinish() {

                skip();
            }
        };
        timer.start();
    }

    @Override
    public void onClick(View v) {

        if (v == next_order) {

            final ProgressDialog progressDialog = new ProgressDialog(CaptchaActivity.this);
            progressDialog.setMessage("Please Wait");
            progressDialog.setCancelable(false);
            progressDialog.show();

            Call<DefaultResponse> call1 = RetrofitClient.getInstance().getApi().createNextOrder(Login.str_user_id);
            call1.enqueue(new Callback<DefaultResponse>() {
                @Override
                public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {

                    progressDialog.cancel();
                    if (response.code() == 201) {

                        AlertDialog.Builder builder = new AlertDialog.Builder(CaptchaActivity.this);
                        builder.setCancelable(false);
                        builder.setMessage("Your request for next order has been sent. Please wait for response");
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.cancel();
                                next_order.setEnabled(false);
                            }
                        }).create().show();
                    }
                }

                @Override
                public void onFailure(Call<DefaultResponse> call, Throwable t) {

                    progressDialog.cancel();
                }
            });
        }

        if (v == btn_continue) {

            if (position >= dataList.size()) {

                position = 0;
                Collections.shuffle(dataList);
            }

            if (right_count >= Integer.parseInt(captcha_count)) {

                completeOrder();
            } else {

                String str_captcha_text;
                str_captcha_text = captcha_text.getText().toString().trim();
                if (TextUtils.isEmpty(str_captcha_text)) {

                    captcha_text.setError("Please Enter Captcha!!");
                    captcha_text.requestFocus();
                    return;
                }

                if (str_captcha_text.equals(dataList.get(position).getCaptcha_text())) {


                    right_count += 1;
                    updateCount();
                    right_wrong.setText(right_count + " / " + wrong_count);

                    Picasso.get().load(image_url + dataList.get(position + 1).getImage()).resize(500, 200).into(captcha_image, new com.squareup.picasso.Callback() {
                        @Override
                        public void onSuccess() {
                            if (timer_running) {

                                timer.cancel();
                                startTimer();
                            } else
                                startTimer();
                        }

                        @Override
                        public void onError(Exception e) {

                        }
                    });
                    captcha_type.setText("* " + dataList.get(position + 1).getCaptcha_type());
                    captcha_text.setText("");
                } else {

                    showSnackBar("Wrong Answer");
                    wrong_count += 1;
                    updateCount();
                    right_wrong.setText(right_count + " / " + wrong_count);

                    Picasso.get().load(image_url + dataList.get(position + 1).getImage()).resize(500, 200).into(captcha_image, new com.squareup.picasso.Callback() {
                        @Override
                        public void onSuccess() {
                            if (timer_running) {

                                timer.cancel();
                                startTimer();
                            } else
                                startTimer();
                        }

                        @Override
                        public void onError(Exception e) {

                        }
                    });
                    captcha_type.setText("* " + dataList.get(position + 1).getCaptcha_type());
                    captcha_text.setText("");
                }


                position++;

            }
        }

        if (v == btn_skip) {

            skip();
        }
    }

    private void skip() {

        if (position >= dataList.size()) {

            position = 0;
            Collections.shuffle(dataList);
        }

        if (right_count >= Integer.parseInt(captcha_count)) {

            completeOrder();
        } else {

                Picasso.get().load(image_url + dataList.get(position + 1).getImage()).resize(500, 200).into(captcha_image, new com.squareup.picasso.Callback() {
                    @Override
                    public void onSuccess() {
                        if (timer_running) {

                            timer.cancel();
                            startTimer();
                        } else
                            startTimer();
                    }

                    @Override
                    public void onError(Exception e) {

                    }
                });
                captcha_type.setText("* " + dataList.get(position + 1).getCaptcha_type());
                position++;
            }

        }

    private void updateCount() {

        final ProgressDialog dialog = new ProgressDialog(CaptchaActivity.this);
        dialog.setMessage("Please Wait...");
        dialog.setCancelable(false);
        dialog.show();

        Call<DefaultResponse> call = RetrofitClient.getInstance().getApi().updateUserCount(Login.str_user_id, String.valueOf(right_count), String.valueOf(wrong_count));
        call.enqueue(new Callback<DefaultResponse>() {
            @Override
            public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {
                dialog.cancel();
            }

            @Override
            public void onFailure(Call<DefaultResponse> call, Throwable t) {

                dialog.cancel();
            }
        });
    }

    public void showSnackBar(String msg) {

        Snackbar mSnackBar = Snackbar.make(findViewById(R.id.main_layout), msg, Snackbar.LENGTH_SHORT);
        View view = mSnackBar.getView();
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) view.getLayoutParams();
        params.gravity = Gravity.TOP;
        view.setLayoutParams(params);
        view.setBackgroundColor(Color.RED);
        TextView mainTextView = (TextView) (view).findViewById(android.support.design.R.id.snackbar_text);
        mainTextView.setTextColor(Color.WHITE);
        mSnackBar.show();
    }
}
