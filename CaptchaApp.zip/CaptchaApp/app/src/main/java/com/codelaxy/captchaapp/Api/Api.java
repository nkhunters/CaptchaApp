package com.codelaxy.captchaapp.Api;

import com.codelaxy.captchaapp.Models.CaptchaResponse;
import com.codelaxy.captchaapp.Models.DefaultResponse;
import com.codelaxy.captchaapp.Models.RateResponse;
import com.codelaxy.captchaapp.Models.UserCountResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface Api {

    @FormUrlEncoded
    @POST("login")
    Call<DefaultResponse> login(@Field("user_id") String user_id,
                                @Field("password") String password);

    @GET("getCaptcha")
    Call<CaptchaResponse> getCaptcha();

    @FormUrlEncoded
    @POST("updateUserCount")
    Call<DefaultResponse> updateUserCount(@Field("user_id") String user_id,
                                          @Field("right_count") String right_count,
                                          @Field("wrong_count") String wrong_count);

    @FormUrlEncoded
    @POST("getUserCount")
    Call<UserCountResponse> getUserCount(@Field("user_id") String user_id);

    @GET("getRates")
    Call<RateResponse> getRates();

    @FormUrlEncoded
    @POST("createNextOrder")
    Call<DefaultResponse> createNextOrder(@Field("user_id") String user_id);

    @FormUrlEncoded
    @POST("updateUniqueId")
    Call<DefaultResponse> updateUniqueId(@Field("user_id") String user_id, @Field("unique_id") String unique_id);
}
