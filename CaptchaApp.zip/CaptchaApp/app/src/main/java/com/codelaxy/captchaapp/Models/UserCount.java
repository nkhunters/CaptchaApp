package com.codelaxy.captchaapp.Models;

public class UserCount {

    private String right_count, wrong_count, captcha_count, captcha_rate, unique_id;

    public UserCount(String right_count, String wrong_count, String captcha_count, String captcha_rate, String unique_id) {
        this.right_count = right_count;
        this.wrong_count = wrong_count;
        this.captcha_count = captcha_count;
        this.captcha_rate = captcha_rate;
        this.unique_id = unique_id;
    }

    public String getRight_count() {
        return right_count;
    }

    public String getWrong_count() {
        return wrong_count;
    }

    public String getCaptcha_count() {
        return captcha_count;
    }

    public String getCaptcha_rate() {
        return captcha_rate;
    }

    public String getUnique_id() {
        return unique_id;
    }
}
