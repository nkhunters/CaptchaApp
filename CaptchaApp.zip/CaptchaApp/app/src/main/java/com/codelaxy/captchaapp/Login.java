package com.codelaxy.captchaapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.codelaxy.captchaapp.Api.RetrofitClient;
import com.codelaxy.captchaapp.Models.DefaultResponse;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Login extends AppCompatActivity implements View.OnClickListener {

    @BindView(R.id.user_id)
    EditText user_id;

    @BindView(R.id.password)
    EditText password;

    @BindView(R.id.login)
    Button login;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    public static String str_user_id, str_password, str_time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(R.string.toolbar_title);
        login.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        str_user_id = user_id.getText().toString().trim();
        str_password = password.getText().toString().trim();

        if(TextUtils.isEmpty(str_user_id)){

            user_id.setError("Please Enter User Id.");
            user_id.requestFocus();
            return;
        }

        if(TextUtils.isEmpty(str_password)){

            password.setError("Please Enter Password");
            password.requestFocus();
            return;
        }

        final ProgressDialog dialog = new ProgressDialog(Login.this);
        dialog.setMessage("Please Wait...");
        dialog.setCancelable(false);
        dialog.show();

        Call<DefaultResponse> call = RetrofitClient.getInstance().getApi().login(str_user_id, str_password);
        call.enqueue(new Callback<DefaultResponse>() {
            @Override
            public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {

                dialog.cancel();
                if(response.code() == 201){

                    str_time = response.body().getMessage();
                    finish();
                    Intent intent = new Intent(Login.this, CaptchaActivity.class);
                    startActivity(intent);
                }
                else {

                    Snackbar.make(findViewById(R.id.main_layout), "Invalid username or password Please try again!!", Snackbar.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<DefaultResponse> call, Throwable t) {

                Log.d("niraj", t.getMessage());
                dialog.cancel();
                Snackbar.make(findViewById(R.id.main_layout), "Something went wrong Please check your internet!!", Snackbar.LENGTH_LONG).show();
            }
        });
    }
}
